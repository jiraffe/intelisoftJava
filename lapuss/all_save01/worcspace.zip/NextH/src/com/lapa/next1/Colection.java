package com.lapa.next1;

public abstract class Colection {

	String name = "";
	String pass = "";
	boolean c = true;
	public Object[] arr ;

	
}
