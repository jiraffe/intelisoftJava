package com.lapa.next1;

public interface Serchable {
	public Object Search ();

}
