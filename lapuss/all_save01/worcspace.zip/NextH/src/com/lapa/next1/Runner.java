package com.lapa.next1;

public class Runner {
public static void main(String[] args) {
	UserColection ucol = new UserColection ();
	
}
}
