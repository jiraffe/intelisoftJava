package com.lapa.next1;

public class ItemColection extends Colection {
	

}
