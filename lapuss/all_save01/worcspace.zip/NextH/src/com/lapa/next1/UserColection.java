package com.lapa.next1;

public class UserColection extends Colection implements Serchable {

	@Override
	public Object Search() {
		
		return null ;
	}
	
	
	}


