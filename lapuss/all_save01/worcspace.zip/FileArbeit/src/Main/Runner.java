package Main;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class Runner {
	public static void main(String[] args) throws IOException {
		File f = new File("D:\\���� �.�\\new\\new\\new\\test_new.txt");
		f.getParentFile().mkdirs();
		//f.createNewFile();
		//System.out.println(f.exists());
		Reader r = new FileReader(f);
		while () {
			
		}
		r.close();
	
		
	}

}
