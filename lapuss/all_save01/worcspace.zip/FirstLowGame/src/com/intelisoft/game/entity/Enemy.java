package com.intelisoft.game.entity;

public class Enemy extends AbstractGameObject {

	public Enemy(String name, int health) {
		this.name = name;
		this.health = health;
	}
}