package com.intelisoft.game.enums;

public enum MRT {

	ROAD,	// дорога
	BORDER,	// лес / граница
	ITEM,	// артефакт
	ENEMY,	// враг
	PLAYER	// игрок
	
}
