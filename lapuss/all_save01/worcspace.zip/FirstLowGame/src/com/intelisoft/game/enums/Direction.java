package com.intelisoft.game.enums;

public enum Direction {

	UP,
	DOWN,
	LEFT,
	RIGHT
	
}
