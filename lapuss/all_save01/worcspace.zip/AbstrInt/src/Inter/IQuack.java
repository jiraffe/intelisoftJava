package Inter;

public interface IQuack {
	String iQuak();

}
