package Inter;

public interface Fishing {
	String fishing();

}
