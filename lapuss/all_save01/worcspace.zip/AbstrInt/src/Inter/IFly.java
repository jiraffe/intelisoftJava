package Inter;

public interface IFly {
	
	String ifly();

}
