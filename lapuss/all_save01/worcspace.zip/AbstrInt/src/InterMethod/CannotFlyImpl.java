package InterMethod;

import Inter.IFly;

public class CannotFlyImpl implements IFly	{

	@Override
	public String ifly() {
		return "I can't fly!";
	}

}
