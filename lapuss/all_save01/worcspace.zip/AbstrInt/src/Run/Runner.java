package Run;

import Duckers.RubberDuck;

public class Runner {
	public static void main(String[] args) {
		RubberDuck r = new RubberDuck();
		r.swimm("Hell world");
		System.out.println(r.fish.fishing());
	}

}
