package com.lapa.game1;

public class Index {
	public static void main(String[] args) {
		
	}

}
