package com.lapa.homework3;

public class BUser {
	
	String bUser;
	int uMoney;

	public BUser() {
		bUser = "VANO";
		uMoney = 50;
	};

}
