package com.lapa.homework3;

public class Bancomat {
	
	boolean work;
	int money;
	String bUser;
	
	public Bancomat() {
		work = true;
		money = 10000;
		bUser = "";
		
	}

}
