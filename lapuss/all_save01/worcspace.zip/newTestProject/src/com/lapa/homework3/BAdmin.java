package com.lapa.homework3;


public class BAdmin {
String bAdm;
public BAdmin(){ 
bAdm = "Admin";
}
}
