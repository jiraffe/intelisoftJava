package com.lapa.mass;

public class obert {
	public static void main(String[] args) {
		int a = 1;
		Integer aInt = new Integer(a);
		System.out.println(aInt.equals(a));
	}

}
